@echo off
setlocal

echo ============================================================
echo  olliE HWID Spoofer -- Build Script
echo  Requires: VS 2022, WDK 10.0.26100, test-signing or EV cert
echo ============================================================
echo.

:: ── Locate MSVC + WDK automatically ────────────────────────────────────────
:: Adjust if your VS install is on D: or a non-standard path
set "VSBASE=C:\Program Files\Microsoft Visual Studio\2022\Community"
if not exist "%VSBASE%" set "VSBASE=C:\Program Files\Microsoft Visual Studio\2022\Professional"
if not exist "%VSBASE%" set "VSBASE=C:\Program Files\Microsoft Visual Studio\2022\Enterprise"

if not exist "%VSBASE%" (
    echo [!] Visual Studio 2022 not found — set VSBASE manually in build.bat
    goto fail
)

set "VCVARS=%VSBASE%\VC\Auxiliary\Build\vcvars64.bat"
call "%VCVARS%" >nul 2>&1

echo [*] building loader (user-mode exe)...
cl /nologo /W4 /permissive- /std:c++17 /EHsc /O2 /MT ^
    loader\main.cpp ^
    loader\gen.cpp ^
    loader\spoof_registry.cpp ^
    loader\spoof_wmi.cpp ^
    loader\spoof_nvidia.cpp ^
    loader\spoof_fortnite.cpp ^
    loader\spoof_tpm.cpp ^
    /Fe:bin\spoofer_loader.exe ^
    /link bcrypt.lib advapi32.lib shell32.lib

if errorlevel 1 (
    echo [!] loader build failed
    goto fail
)
echo [+] loader built: bin\spoofer_loader.exe

echo.
echo [*] building kernel driver...
msbuild driver\spoofer.vcxproj ^
    /p:Configuration=Release ^
    /p:Platform=x64 ^
    /p:OutDir="%~dp0bin\\" ^
    /nologo /v:m

if errorlevel 1 (
    echo [!] driver build failed
    goto fail
)
echo [+] driver built: bin\spoofer.sys

echo.
echo ============================================================
echo  Build complete.
echo  Output: bin\spoofer_loader.exe + bin\spoofer.sys
echo ============================================================
goto end

:fail
echo.
echo [!] Build failed. See errors above.
pause
exit /b 1

:end
pause
