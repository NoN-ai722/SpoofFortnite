# olliE HWID Spoofer
**@oll.fx — discord.gg/ojailbreaks**

---

## What this spoofs

| Surface | Method | Persistence |
|---|---|---|
| MachineGuid, ComputerName, Hostname | Registry | Permanent |
| HwProfileGuid, ProductId, EditionID | Registry | Permanent |
| SusClientId, SQM MachineId, DPId4 | Registry | Permanent |
| BootGuid, BootOrder | Registry | Permanent |
| UnlockIDCopy, OfflineUniqueID*, PlatformModuleData | Registry | Permanent |
| NDIS MAC (NetworkAddress), NetCfgInstanceId | Registry + Driver | Permanent |
| DHCPv4 Client ID, DHCPv6 DUID/IAID | Registry | Permanent |
| ARP / UuidNode (cached MAC) | Registry | Permanent |
| NetBT TransportBindName | Registry | Permanent |
| Bluetooth BDAddress | Registry | Permanent |
| USB Serials (Enum\USB) | Registry | Permanent* |
| SCSI Port 0 serial | Registry | Permanent |
| EDID serial + product code | Registry (EDID binary patch) | Permanent |
| NVIDIA GPU serial, monitor ID, GpuGuid | Registry | Permanent |
| Win32_DiskDrive / MSFT_PhysicalDisk serial | Registry + Driver | Permanent |
| NVMe Identify Ctrl serial | Driver (IRP hook) | Permanent (auto-start) |
| ATA/SCSI/SMART serial + WWN | Driver (IRP hook) | Permanent (auto-start) |
| SMBIOS UUID (physical memory) | Driver | Until reboot (re-patched on next boot by driver) |
| TPM name/SHA256/SHA1 caches, AIK, SRK, EK | Registry | Permanent |
| EK cert thumbprints (RSA + ECC) | Registry | Permanent |
| BootCurrent / BootIdent | Registry | Permanent |
| Fortnite / EAC / BattlEye trace files | File wipe | Permanent |
| Volume serial | Registry (VBR raw write requires extra step — see below) | Permanent |

*USB: re-enumerates on replug; driver kernel hook for persistent USB requires kernel PnP hook.

---

## Prerequisites

### 1. Visual Studio 2022
Download: https://visualstudio.microsoft.com/vs/
- Workload: **Desktop development with C++**
- Component: **C++ CMake tools** (optional but useful)

### 2. Windows Driver Kit (WDK) 10.0.26100
Download: https://learn.microsoft.com/en-us/windows-hardware/drivers/download-the-wdk
- Must match your VS 2022 install
- Install WDK **after** VS — the installer adds the kernel driver project template to VS

### 3. Test signing OR a valid EV cert
The kernel driver (`.sys`) must be signed to load on Windows 10/11.

**Option A — Test signing (VM / test machine only):**
```
bcdedit /set testsigning on
bcdedit /set nointegritychecks on
```
Reboot. Now self-signed drivers load.

**Option B — Self-sign for test:**
```
makecert -r -pe -ss PrivateCertStore -n "CN=SpooferTestCert" SpooferTest.cer
signtool sign /v /s PrivateCertStore /n "SpooferTestCert" /fd sha256 bin\spoofer.sys
```
Then import SpooferTest.cer into Trusted Root CA + Trusted Publishers.

**Option C — DSE bypass (no test signing needed, advanced):**
Use a known DSE bypass technique (kdmapper, TDL4, etc.) to load the unsigned driver directly.
Not covered here — look up `kdmapper` on GitHub.

---

## Build steps

```
1. Open: "x64 Native Tools Command Prompt for VS 2022"
   (Start → Visual Studio 2022 → x64 Native Tools Command Prompt)

2. cd into the spoofer\ folder:
   cd C:\path\to\spoofer

3. Create the bin\ folder:
   mkdir bin

4. Run the build script:
   build.bat
```

Output after successful build:
```
bin\spoofer_loader.exe   ← user-mode loader (run this)
bin\spoofer.sys          ← kernel driver (placed next to the exe)
```

---

## Running

**Always run as Administrator.**

```
1. Copy bin\spoofer_loader.exe and bin\spoofer.sys to the same folder.

2. Right-click spoofer_loader.exe → Run as administrator

3. The loader will:
   a. Generate fresh random identifiers for this spoof session
   b. Install spoofer.sys as an auto-start kernel driver
      (sc create spoofer type=kernel start=auto)
   c. Start the driver immediately
   d. Write all registry surfaces (MAC, serials, GUIDs, TPM cache, etc.)
   e. Wipe Fortnite / EAC / BattlEye trace files

4. Reboot.

5. Launch Fortnite normally.
```

The driver is set to `SERVICE_AUTO_START` — it loads at every boot before
EasyAntiCheat initialises. The spoof is fully persistent across reboots.

---

## Volume serial (optional extra step)

The registry path covers what EAC reads. If you want the raw VBR serial
patched too (what `vol C:` shows):

```cmd
:: Run as admin — locks the volume briefly
:: Replace XXXXXXXX with the volume_serial printed by the spoofer
diskpart
  select volume C
  filesystems
  exit

:: Raw VBR patch via Python (run in admin cmd):
python -c "
import struct, sys
h = open(r'\\\\.\PhysicalDrive0', 'r+b')
h.seek(0x1C)                      # NTFS VBR serial offset
# h.write(struct.pack('<I', 0xXXXXXXXX))  # paste your volume_serial here
h.close()
"
```
Or just use the registry path — EAC reads that first.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `StartService failed: 577` | Test signing not enabled — run `bcdedit /set testsigning on` and reboot |
| `CreateService failed: 5` | Not running as Administrator |
| `StartService failed: 2` | `spoofer.sys` not in the same folder as `spoofer_loader.exe` |
| Driver installs but serials unchanged | Reboot required — IRP hooks apply after the driver is loaded at boot |
| EAC still detecting | Rerun spoofer after full reboot, make sure all Fortnite processes are closed |
| USB serial resets after replug | Expected — registry spoof covers plugged-in state; full PnP hook needed for persistent USB |

---

## Uninstall

```cmd
:: Run as admin
sc stop spoofer
sc delete spoofer
del C:\path\to\spoofer.sys
del C:\path\to\spoofer_loader.exe

:: Disable test signing if you enabled it
bcdedit /set testsigning off
bcdedit /set nointegritychecks off
```

---

*absolute olliE — @oll.fx cooked something dangerous — discord.gg/ojailbreaks*
