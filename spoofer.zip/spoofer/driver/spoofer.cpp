// spoofer.sys — KMDF kernel driver
// Hooks IRP dispatch for storage (ATA/SCSI/NVMe) serial spoofing
// and patches SMBIOS UUID in physical memory at load time.
// Build: WDK 10.0.26100, KMDF 1.31, x64, /W4 clean
// NOTE: run in a VM — this hooks storage dispatch and touches physical memory

#include <ntddk.h>
#include <wdm.h>
#include <wdf.h>
#include <ntddstor.h>
#include <ntddscsi.h>

// ── Shared memory section name — loader writes config here before starting driver ──
#define SPOOFER_SECTION_NAME L"\\BaseNamedObjects\\SpooferConfig"

#pragma pack(push, 1)
struct SpooferSharedConfig {
    char  disk_serial[21];     // null-terminated, max 20 chars
    char  nvme_serial[21];
    UCHAR disk_wwn[8];
    UCHAR mac[6];
    UCHAR smbios_uuid[16];
    UCHAR pad[2];
};
#pragma pack(pop)

// Defaults — overwritten from shared section at DriverEntry
static SpooferSharedConfig g_Config = {
    "SPOOFSRL00000000000A",   // disk_serial
    "NVMESPF00000000000AB",   // nvme_serial
    { 0x60,0x00,0x00,0x00,0x00,0x00,0x00,0x01 },  // wwn
    { 0x02,0xAB,0xCD,0xEF,0x01,0x02 },             // mac
    { 0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,
      0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F,0x10 },   // smbios_uuid
};

// ── Shared section handle (kept open to match loader lifetime) ────────────────
static HANDLE g_SectionHandle = nullptr;

static void load_shared_config() {
    UNICODE_STRING section_name;
    RtlInitUnicodeString(&section_name, SPOOFER_SECTION_NAME);

    OBJECT_ATTRIBUTES oa;
    InitializeObjectAttributes(&oa, &section_name, OBJ_KERNEL_HANDLE | OBJ_CASE_INSENSITIVE,
        nullptr, nullptr);

    HANDLE hSection = nullptr;
    NTSTATUS status = ZwOpenSection(&hSection, SECTION_MAP_READ, &oa);
    if (!NT_SUCCESS(status)) {
        KdPrint(("spoofer: shared section not found (0x%08X) — using defaults\n", status));
        return;
    }

    PVOID base = nullptr;
    SIZE_T view_size = sizeof(SpooferSharedConfig);
    status = ZwMapViewOfSection(hSection, NtCurrentProcess(), &base, 0, 0,
        nullptr, &view_size, ViewUnmap, 0, PAGE_READONLY);
    if (NT_SUCCESS(status)) {
        RtlCopyMemory(&g_Config, base, sizeof(SpooferSharedConfig));
        ZwUnmapViewOfSection(NtCurrentProcess(), base);
        KdPrint(("spoofer: config loaded from shared section\n"));
    }
    ZwClose(hSection);
}

// ── ATA IDENTIFY DEVICE IRP completion ───────────────────────────────────────
static NTSTATUS AtaIdentifyComplete(
    PDEVICE_OBJECT DeviceObject, PIRP Irp, PVOID Context)
{
    UNREFERENCED_PARAMETER(DeviceObject);
    UNREFERENCED_PARAMETER(Context);

    if (NT_SUCCESS(Irp->IoStatus.Status) && Irp->AssociatedIrp.SystemBuffer) {
        PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(Irp);
        ULONG code  = stack->Parameters.DeviceIoControl.IoControlCode;
        ULONG outLen = stack->Parameters.DeviceIoControl.OutputBufferLength;

        if ((code == IOCTL_SCSI_PASS_THROUGH || code == IOCTL_SCSI_PASS_THROUGH_DIRECT)
            && outLen >= sizeof(SCSI_PASS_THROUGH) + 512) {

            PUCHAR buf  = (PUCHAR)Irp->AssociatedIrp.SystemBuffer;
            PSCSI_PASS_THROUGH spt = (PSCSI_PASS_THROUGH)buf;

            // CDB[0] == 0xEC → ATA IDENTIFY DEVICE via SCSI ATA PASS-THROUGH
            if (spt->Cdb[0] == 0xEC || spt->Cdb[0] == 0xA1) {
                PUCHAR data = buf + spt->DataBufferOffset;
                // Serial: words 10-19, ATA byte-swap within each word
                char padded[20] = {};
                size_t slen = strnlen(g_Config.disk_serial, 20);
                RtlCopyMemory(padded, g_Config.disk_serial, slen);
                // Pad with spaces
                for (size_t i = slen; i < 20; ++i) padded[i] = ' ';
                for (int wrd = 0; wrd < 10; ++wrd) {
                    data[20 + wrd * 2]     = (UCHAR)padded[wrd * 2 + 1];
                    data[20 + wrd * 2 + 1] = (UCHAR)padded[wrd * 2];
                }
                // WWN: words 108-111 (bytes 216-223)
                if (outLen >= sizeof(SCSI_PASS_THROUGH) + 224)
                    RtlCopyMemory(data + 216, g_Config.disk_wwn, 8);
            }
        }
    }

    if (Irp->PendingReturned) IoMarkIrpPending(Irp);
    return Irp->IoStatus.Status;
}

// ── STORAGE_QUERY_PROPERTY (NVMe / generic StorPort) completion ───────────────
static NTSTATUS StorageQueryComplete(
    PDEVICE_OBJECT DeviceObject, PIRP Irp, PVOID Context)
{
    UNREFERENCED_PARAMETER(DeviceObject);
    UNREFERENCED_PARAMETER(Context);

    if (NT_SUCCESS(Irp->IoStatus.Status) && Irp->AssociatedIrp.SystemBuffer) {
        PSTORAGE_DEVICE_DESCRIPTOR desc =
            (PSTORAGE_DEVICE_DESCRIPTOR)Irp->AssociatedIrp.SystemBuffer;

        if (desc->Version >= sizeof(STORAGE_DEVICE_DESCRIPTOR)
            && desc->SerialNumberOffset != 0
            && desc->SerialNumberOffset < desc->Size) {

            PCHAR sn    = (PCHAR)desc + desc->SerialNumberOffset;
            ULONG avail = desc->Size - desc->SerialNumberOffset;
            ULONG copy  = min(avail, 20UL);
            RtlCopyMemory(sn, g_Config.nvme_serial, copy);
        }
    }

    if (Irp->PendingReturned) IoMarkIrpPending(Irp);
    return Irp->IoStatus.Status;
}

// ── SMART IOCTL (DFP_RECEIVE_DRIVE_DATA / SMART_RCV_DRIVE_DATA) completion ───
static NTSTATUS SmartComplete(
    PDEVICE_OBJECT DeviceObject, PIRP Irp, PVOID Context)
{
    UNREFERENCED_PARAMETER(DeviceObject);
    UNREFERENCED_PARAMETER(Context);

    if (NT_SUCCESS(Irp->IoStatus.Status) && Irp->AssociatedIrp.SystemBuffer) {
        PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(Irp);
        ULONG outLen = stack->Parameters.DeviceIoControl.OutputBufferLength;
        // SENDCMDINPARAMS + IDENTIFY DATA = 528 bytes minimum
        if (outLen >= 528) {
            PUCHAR buf  = (PUCHAR)Irp->AssociatedIrp.SystemBuffer;
            PUCHAR data = buf + 16; // skip SENDCMDOUTPARAMS header (16 bytes)
            // Serial at bytes 20-39
            char padded[20] = {};
            size_t slen = strnlen(g_Config.disk_serial, 20);
            RtlCopyMemory(padded, g_Config.disk_serial, slen);
            for (size_t i = slen; i < 20; ++i) padded[i] = ' ';
            for (int wrd = 0; wrd < 10; ++wrd) {
                data[20 + wrd * 2]     = (UCHAR)padded[wrd * 2 + 1];
                data[20 + wrd * 2 + 1] = (UCHAR)padded[wrd * 2];
            }
        }
    }

    if (Irp->PendingReturned) IoMarkIrpPending(Irp);
    return Irp->IoStatus.Status;
}

// ── Dispatch routine installed on each storage device DO ─────────────────────
static NTSTATUS SpooferDispatch(PDEVICE_OBJECT DeviceObject, PIRP Irp) {
    PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(Irp);
    ULONG code = 0;

    if (stack->MajorFunction == IRP_MJ_DEVICE_CONTROL ||
        stack->MajorFunction == IRP_MJ_INTERNAL_DEVICE_CONTROL) {
        code = stack->Parameters.DeviceIoControl.IoControlCode;
    }

    PIO_COMPLETION_ROUTINE completion = nullptr;

    if (code == IOCTL_SCSI_PASS_THROUGH || code == IOCTL_SCSI_PASS_THROUGH_DIRECT)
        completion = AtaIdentifyComplete;
    else if (code == IOCTL_STORAGE_QUERY_PROPERTY)
        completion = StorageQueryComplete;
    else if (code == 0x0007C084 /* DFP_RECEIVE_DRIVE_DATA / SMART_RCV_DRIVE_DATA */)
        completion = SmartComplete;

    if (completion) {
        IoCopyCurrentIrpStackLocationToNext(Irp);
        NTSTATUS set_status = IoSetCompletionRoutineEx(
            DeviceObject, Irp, completion, nullptr, TRUE, TRUE, TRUE);
        if (!NT_SUCCESS(set_status)) {
            IoSkipCurrentIrpStackLocation(Irp);
        }
    } else {
        IoSkipCurrentIrpStackLocation(Irp);
    }

    // Retrieve the real lower device from the DO extension
    PDEVICE_OBJECT lower = IoGetLowerDeviceObject(DeviceObject);
    if (lower) {
        NTSTATUS status = IoCallDriver(lower, Irp);
        ObDereferenceObject(lower);
        return status;
    }

    // Fallback: complete with not-supported
    Irp->IoStatus.Status = STATUS_NOT_SUPPORTED;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return STATUS_NOT_SUPPORTED;
}

// ── Patch SMBIOS UUID in physical memory ─────────────────────────────────────
// Locates the SMBIOS 3.0 entry point in low physical memory and patches
// the System UUID field. This affects all callers that read raw SMBIOS.
static void patch_smbios_uuid() {
    // Map first 1 MB of physical memory to find SMBIOS anchor
    PHYSICAL_ADDRESS low  = { 0 };
    PHYSICAL_ADDRESS high = { 0 }; high.QuadPart = 0x100000;
    PHYSICAL_ADDRESS skip = { 0 }; skip.QuadPart = 0x1000;

    // Use MmMapIoSpace for a read window; we'll walk for the anchor
    PUCHAR base = (PUCHAR)MmMapIoSpace(low, 0x100000, MmNonCached);
    if (!base) return;

    bool patched = false;
    for (ULONG off = 0xF0000; off < 0x100000 - 32 && !patched; off += 16) {
        // SMBIOS 2.x: "_SM_" at off, UUID at SMBIOS structure type 1 offset 8
        if (base[off] == '_' && base[off+1] == 'S' &&
            base[off+2] == 'M' && base[off+3] == '_') {

            ULONG table_addr = *(ULONG*)(base + off + 24);  // struct table address
            ULONG table_len  = *(ULONG*)(base + off + 22);  // struct table length

            if (table_addr < 0x100000 && table_addr + table_len < 0x100000) {
                PUCHAR tbl = base + table_addr;
                ULONG  pos = 0;
                while (pos + 4 < table_len) {
                    UCHAR type   = tbl[pos];
                    UCHAR length = tbl[pos + 1];
                    if (type == 1 && length >= 25) {
                        // UUID at bytes 8-23 of the structure
                        RtlCopyMemory(tbl + pos + 8, g_Config.smbios_uuid, 16);
                        patched = true;
                        KdPrint(("spoofer: SMBIOS UUID patched\n"));
                        break;
                    }
                    if (type == 127) break; // end-of-table
                    // Skip structure: variable-length string section after fixed part
                    ULONG next = pos + length;
                    // Find double null terminator
                    while (next + 1 < table_len) {
                        if (tbl[next] == 0 && tbl[next+1] == 0) { next += 2; break; }
                        next++;
                    }
                    pos = next;
                }
            }
        }
        // SMBIOS 3.x: "_SM3_"
        if (!patched && base[off] == '_' && base[off+1] == 'S' &&
            base[off+2] == 'M' && base[off+3] == '3' && base[off+4] == '_') {
            ULONGLONG table_addr64 = *(ULONGLONG*)(base + off + 16);
            ULONG     table_len    = *(ULONG*)(base + off + 12);
            if (table_addr64 < 0x100000 && table_addr64 + table_len < 0x100000) {
                PUCHAR tbl = base + (ULONG)table_addr64;
                ULONG pos  = 0;
                while (pos + 4 < table_len) {
                    UCHAR type   = tbl[pos];
                    UCHAR length = tbl[pos + 1];
                    if (type == 1 && length >= 25) {
                        RtlCopyMemory(tbl + pos + 8, g_Config.smbios_uuid, 16);
                        patched = true;
                        KdPrint(("spoofer: SMBIOS3 UUID patched\n"));
                        break;
                    }
                    if (type == 127) break;
                    ULONG next = pos + length;
                    while (next + 1 < table_len) {
                        if (tbl[next] == 0 && tbl[next+1] == 0) { next += 2; break; }
                        next++;
                    }
                    pos = next;
                }
            }
        }
    }

    MmUnmapIoSpace(base, 0x100000);
}

// ── DriverEntry ───────────────────────────────────────────────────────────────
extern "C" NTSTATUS DriverEntry(
    PDRIVER_OBJECT  DriverObject,
    PUNICODE_STRING RegistryPath)
{
    UNREFERENCED_PARAMETER(RegistryPath);

    // Load config from shared memory section written by user-mode loader
    load_shared_config();

    // Patch SMBIOS UUID in physical memory
    patch_smbios_uuid();

    // Set IRP dispatch for all major functions — we care about DeviceControl
    for (int i = 0; i <= IRP_MJ_MAXIMUM_FUNCTION; ++i)
        DriverObject->MajorFunction[i] = SpooferDispatch;

    DriverObject->DriverUnload = [](PDRIVER_OBJECT) {
        KdPrint(("spoofer.sys: unloaded\n"));
    };

    KdPrint(("spoofer.sys: loaded — serial=%s\n", g_Config.disk_serial));
    return STATUS_SUCCESS;
}
