#include "spoof_wmi.h"
#include "config.h"
#include "gen.h"
#include <windows.h>
#include <string>
#include <iostream>

static std::wstring w(const std::string& s) { return std::wstring(s.begin(), s.end()); }

static bool write_sz(HKEY root, const wchar_t* path, const wchar_t* name, const std::wstring& val) {
    HKEY hk;
    if (RegCreateKeyExW(root, path, 0, nullptr, 0,
        KEY_SET_VALUE | KEY_WOW64_64KEY, nullptr, &hk, nullptr) != ERROR_SUCCESS)
        return false;
    bool ok = RegSetValueExW(hk, name, 0, REG_SZ,
        (const BYTE*)val.c_str(), (DWORD)((val.size() + 1) * 2)) == ERROR_SUCCESS;
    RegCloseKey(hk);
    return ok;
}

static bool write_bin(HKEY root, const wchar_t* path, const wchar_t* name,
    const void* data, DWORD sz) {
    HKEY hk;
    if (RegCreateKeyExW(root, path, 0, nullptr, 0,
        KEY_SET_VALUE | KEY_WOW64_64KEY, nullptr, &hk, nullptr) != ERROR_SUCCESS)
        return false;
    bool ok = RegSetValueExW(hk, name, 0, REG_BINARY,
        (const BYTE*)data, sz) == ERROR_SUCCESS;
    RegCloseKey(hk);
    return ok;
}

void spoof_wmi() {
    // Win32_DiskDrive / Win32_PhysicalMedia serial number
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Services\\disk\\Enum",
        L"SerialNumber", w(g_cfg.disk_serial));

    // Win32_ComputerSystemProduct / SMBIOS UUID
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Control\\SystemInformation",
        L"ComputerHardwareId", w(g_cfg.smbios_uuid));

    // SMBIOS serial / product
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Control\\SystemInformation",
        L"SystemProductName", w(g_cfg.smbios_product));
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Control\\SystemInformation",
        L"BiosVersion", w(g_cfg.smbios_serial));

    // DigitalProductId
    write_sz(HKEY_LOCAL_MACHINE,
        L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion",
        L"DigitalProductId", w(g_cfg.product_id));

    // WmiData EDID kernel path
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e96e-e325-11ce-bfc1-08002be10318}\\0000",
        L"HardwareID", w("MONITOR\\MST" + g_cfg.edid_product_code));

    // DIMM serial — MSMMemory WMI class cache
    write_sz(HKEY_LOCAL_MACHINE,
        L"HARDWARE\\RESOURCEMAP\\System Resources\\Physical Memory",
        L"SerialNumber", w(g_cfg.dimm_serial));

    // MSFT_PhysicalDisk / StorNVMe serial
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Services\\stornvme\\Parameters\\Device",
        L"SerialNumber", w(g_cfg.disk_serial));

    // StorAHCI serial (for SATA drives)
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Services\\storahci\\Parameters\\Device",
        L"SerialNumber", w(g_cfg.disk_serial));

    // VPD 0x83 / SQP UniqueId cache
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Services\\disk\\Enum",
        L"UniqueId", w(g_cfg.disk_serial));

    // Volume serial (8 hex chars — filesystem VBR path)
    // This writes the cached value; raw VBR write requires raw disk handle
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Services\\disk\\Enum",
        L"VolumeSerial", w(g_cfg.volume_serial));

    // ACPI Table OEM ID stub
    write_sz(HKEY_LOCAL_MACHINE,
        L"HARDWARE\\ACPI\\DSDT",
        L"OemId", w(g_cfg.smbios_product));

    std::cout << "[+] wmi done\n";
}
