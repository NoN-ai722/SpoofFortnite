#pragma once
void spoof_nvidia();
