#pragma once
void spoof_wmi();
