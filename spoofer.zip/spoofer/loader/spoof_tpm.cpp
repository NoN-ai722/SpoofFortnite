#include "spoof_tpm.h"
#include "config.h"
#include "gen.h"
#include <windows.h>
#include <string>
#include <iostream>

static std::wstring w(const std::string& s) { return std::wstring(s.begin(), s.end()); }

static bool write_sz(HKEY root, const wchar_t* path, const wchar_t* name, const std::wstring& val) {
    HKEY hk;
    if (RegCreateKeyExW(root, path, 0, nullptr, 0,
        KEY_SET_VALUE | KEY_WOW64_64KEY, nullptr, &hk, nullptr) != ERROR_SUCCESS)
        return false;
    bool ok = RegSetValueExW(hk, name, 0, REG_SZ,
        (const BYTE*)val.c_str(), (DWORD)((val.size() + 1) * 2)) == ERROR_SUCCESS;
    RegCloseKey(hk);
    return ok;
}

static bool write_bin(HKEY root, const wchar_t* path, const wchar_t* name,
    const void* data, DWORD sz) {
    HKEY hk;
    if (RegCreateKeyExW(root, path, 0, nullptr, 0,
        KEY_SET_VALUE | KEY_WOW64_64KEY, nullptr, &hk, nullptr) != ERROR_SUCCESS)
        return false;
    bool ok = RegSetValueExW(hk, name, 0, REG_BINARY,
        (const BYTE*)data, sz) == ERROR_SUCCESS;
    RegCloseKey(hk);
    return ok;
}

void spoof_tpm() {
    const wchar_t* tpm_wmi  = L"SYSTEM\\CurrentControlSet\\Services\\TPM\\WMI";
    const wchar_t* tpm_aik  = L"SYSTEM\\CurrentControlSet\\Services\\TPM\\AttestationData";
    const wchar_t* tpm_ek   = L"SYSTEM\\CurrentControlSet\\Services\\TPM\\EK";
    const wchar_t* tpm_srk  = L"SYSTEM\\CurrentControlSet\\Services\\TPM\\WMI\\SRK";
    const wchar_t* tpm_ekk  = L"SYSTEM\\CurrentControlSet\\Services\\TPM\\WMI\\EK";
    const wchar_t* tpm_plat = L"SYSTEM\\CurrentControlSet\\Services\\TPM\\WMI\\Platform";

    // name, qualifiedName, publicAreaSHA256, uniqueSHA1, uniqueSHA256 — base WMI surface
    write_sz(HKEY_LOCAL_MACHINE, tpm_wmi, L"Name",             w(g_cfg.tpm_name_sha256));
    write_sz(HKEY_LOCAL_MACHINE, tpm_wmi, L"QualifiedName",    w(g_cfg.tpm_name_sha256));
    write_sz(HKEY_LOCAL_MACHINE, tpm_wmi, L"PublicAreaSHA256", w(g_cfg.tpm_pub_sha256));
    write_sz(HKEY_LOCAL_MACHINE, tpm_wmi, L"UniqueSHA1",       w(g_cfg.tpm_srk_sha1));
    write_sz(HKEY_LOCAL_MACHINE, tpm_wmi, L"UniqueSHA256",     w(g_cfg.tpm_name_sha256));

    // Three repeated identity blocks (SRK, EK, Platform)
    const wchar_t* blocks[] = { tpm_srk, tpm_ekk, tpm_plat };
    for (auto& bp : blocks) {
        write_sz(HKEY_LOCAL_MACHINE, bp, L"Name",             w(g_cfg.tpm_name_sha256));
        write_sz(HKEY_LOCAL_MACHINE, bp, L"QualifiedName",    w(g_cfg.tpm_name_sha256));
        write_sz(HKEY_LOCAL_MACHINE, bp, L"PublicAreaSHA256", w(g_cfg.tpm_pub_sha256));
        write_sz(HKEY_LOCAL_MACHINE, bp, L"UniqueSHA1",       w(g_cfg.tpm_srk_sha1));
        write_sz(HKEY_LOCAL_MACHINE, bp, L"UniqueSHA256",     w(g_cfg.tpm_name_sha256));
    }

    // WindowsAIKHash / SRKPub SHA1
    write_sz(HKEY_LOCAL_MACHINE, tpm_aik, L"WindowsAIKHash", w(g_cfg.tpm_name_sha256));
    write_sz(HKEY_LOCAL_MACHINE, tpm_aik, L"SRKPubSHA1",     w(g_cfg.tpm_srk_sha1));

    // EKPub SHA1 / SHA256
    write_sz(HKEY_LOCAL_MACHINE, tpm_ek, L"EKPubSHA1",   w(g_cfg.tpm_ek_sha1));
    write_sz(HKEY_LOCAL_MACHINE, tpm_ek, L"EKPubSHA256", w(g_cfg.tpm_ek_sha256));

    // RSA EK certificate thumbprint / serial
    auto rsa_thumb = gen::random_hex(20);
    auto rsa_sn    = gen::random_serial(16);
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Services\\TPM\\EK\\RSA",
        L"Thumbprint",    w(rsa_thumb));
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Services\\TPM\\EK\\RSA",
        L"CertSHA1",      w(rsa_thumb));
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Services\\TPM\\EK\\RSA",
        L"SerialNumber",  w(rsa_sn));

    // ECC EK certificate thumbprint / serial
    auto ecc_thumb = gen::random_hex(20);
    auto ecc_sn    = gen::random_serial(16);
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Services\\TPM\\EK\\ECC",
        L"Thumbprint",    w(ecc_thumb));
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Services\\TPM\\EK\\ECC",
        L"CertSHA1",      w(ecc_thumb));
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Services\\TPM\\EK\\ECC",
        L"SerialNumber",  w(ecc_sn));

    // BootCurrent / BootIdent
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Control\\SecureBoot\\State",
        L"BootCurrent", w(g_cfg.boot_guid));
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Control\\SecureBoot\\State",
        L"BootIdent",   w(gen::random_hex(16)));

    std::cout << "[+] tpm done\n";
}
