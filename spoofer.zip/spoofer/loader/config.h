#pragma once
#include <string>

struct SpoofConfig {
    std::string mac;
    std::string disk_serial;
    std::string disk_wwn;
    std::string smbios_uuid;
    std::string smbios_serial;
    std::string smbios_product;
    std::string dimm_serial;
    std::string machine_guid;
    std::string computer_name;
    std::string hw_profile_guid;
    std::string product_id;
    std::string boot_guid;
    std::string sqm_machine_id;
    std::string sus_client_id;
    std::string volume_serial;
    std::string edid_serial;
    std::string edid_product_code;
    std::string nvidia_serial;
    std::string nvidia_monitor_id;
    std::string tpm_name_sha256;
    std::string tpm_srk_sha1;
    std::string tpm_ek_sha1;
    std::string tpm_ek_sha256;
    std::string tpm_pub_sha256;
};

extern SpoofConfig g_cfg;
