#include <windows.h>
#include <iostream>
#include <string>
#include "config.h"
#include "gen.h"
#include "spoof_registry.h"
#include "spoof_wmi.h"
#include "spoof_nvidia.h"
#include "spoof_fortnite.h"
#include "spoof_tpm.h"
#pragma comment(lib, "advapi32.lib")

SpoofConfig g_cfg;

static bool is_admin() {
    BOOL result = FALSE;
    PSID admin_group = nullptr;
    SID_IDENTIFIER_AUTHORITY nt_authority = SECURITY_NT_AUTHORITY;
    if (AllocateAndInitializeSid(&nt_authority, 2,
        SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_ADMINS,
        0, 0, 0, 0, 0, 0, &admin_group)) {
        CheckTokenMembership(nullptr, admin_group, &result);
        FreeSid(admin_group);
    }
    return result == TRUE;
}

static bool install_driver_autostart(const wchar_t* driver_path) {
    SC_HANDLE scm = OpenSCManagerW(nullptr, nullptr, SC_MANAGER_CREATE_SERVICE);
    if (!scm) {
        std::cout << "[!] OpenSCManager failed: " << GetLastError() << "\n";
        return false;
    }
    // Try create; if it exists, open it
    SC_HANDLE svc = CreateServiceW(scm, L"spoofer", L"HWID Spoofer Driver",
        SERVICE_ALL_ACCESS, SERVICE_KERNEL_DRIVER,
        SERVICE_AUTO_START,   // <-- auto-start = permanent across reboots
        SERVICE_ERROR_NORMAL,
        driver_path,
        nullptr, nullptr, nullptr, nullptr, nullptr);

    if (!svc) {
        DWORD err = GetLastError();
        if (err == ERROR_SERVICE_EXISTS) {
            svc = OpenServiceW(scm, L"spoofer", SERVICE_ALL_ACCESS);
            if (svc) {
                // Update to auto-start in case it was manual before
                SERVICE_DELAYED_AUTO_START_INFO dai = { FALSE };
                ChangeServiceConfig2W(svc, SERVICE_CONFIG_DELAYED_AUTO_START_INFO, &dai);
            }
        } else {
            std::cout << "[!] CreateService failed: " << err << "\n";
            CloseServiceHandle(scm);
            return false;
        }
    }

    if (svc) {
        // Start it now if not already running
        if (!StartServiceW(svc, 0, nullptr)) {
            DWORD err = GetLastError();
            if (err != ERROR_SERVICE_ALREADY_RUNNING) {
                std::cout << "[!] StartService failed: " << err
                          << " (test signing on?)\n";
            }
        }
        CloseServiceHandle(svc);
    }
    CloseServiceHandle(scm);
    return true;
}

static void generate_session() {
    g_cfg.mac               = gen::random_mac();
    g_cfg.disk_serial       = gen::random_serial(20);
    g_cfg.disk_wwn          = gen::random_hex(8);
    g_cfg.smbios_uuid       = gen::random_guid();
    g_cfg.smbios_serial     = gen::random_serial(12);
    g_cfg.smbios_product    = gen::random_serial(8);
    g_cfg.dimm_serial       = gen::random_serial(8);
    g_cfg.machine_guid      = gen::random_guid();
    g_cfg.computer_name     = "DESKTOP-" + gen::random_serial(7);
    g_cfg.hw_profile_guid   = gen::random_guid();
    g_cfg.product_id        = gen::random_serial(5) + "-" + gen::random_serial(5)
                            + "-" + gen::random_serial(5) + "-" + gen::random_serial(5);
    g_cfg.boot_guid         = gen::random_guid();
    g_cfg.sqm_machine_id    = gen::random_guid();
    g_cfg.sus_client_id     = gen::random_guid();
    g_cfg.volume_serial     = gen::random_hex(4);
    g_cfg.edid_serial       = gen::random_serial(13);
    g_cfg.edid_product_code = gen::random_hex(2);
    g_cfg.nvidia_serial     = gen::random_serial(16);
    g_cfg.nvidia_monitor_id = gen::random_hex(4);
    g_cfg.tpm_name_sha256   = gen::random_hex(32);
    g_cfg.tpm_srk_sha1      = gen::random_hex(20);
    g_cfg.tpm_ek_sha1       = gen::random_hex(20);
    g_cfg.tpm_ek_sha256     = gen::random_hex(32);
    g_cfg.tpm_pub_sha256    = gen::random_hex(32);
}

static void print_session() {
    std::cout << "\n========================================\n";
    std::cout << " HWID SPOOFER — session identifiers\n";
    std::cout << "========================================\n";
    std::cout << " MAC          : " << g_cfg.mac            << "\n";
    std::cout << " Disk Serial  : " << g_cfg.disk_serial    << "\n";
    std::cout << " SMBIOS UUID  : " << g_cfg.smbios_uuid    << "\n";
    std::cout << " MachineGuid  : " << g_cfg.machine_guid   << "\n";
    std::cout << " ComputerName : " << g_cfg.computer_name  << "\n";
    std::cout << " ProductId    : " << g_cfg.product_id     << "\n";
    std::cout << " BootGuid     : " << g_cfg.boot_guid      << "\n";
    std::cout << "========================================\n\n";
}

int main(int argc, char* argv[]) {
    std::cout << " olliE HWID Spoofer\n";
    std::cout << " @oll.fx — discord.gg/ojailbreaks\n\n";

    if (!is_admin()) {
        std::cout << "[!] needs Administrator — right-click -> Run as administrator\n";
        system("pause");
        return 1;
    }

    generate_session();
    print_session();

    // Locate driver next to the exe
    wchar_t exe_path[MAX_PATH] = {};
    GetModuleFileNameW(nullptr, exe_path, MAX_PATH);
    std::wstring driver_path(exe_path);
    auto sep = driver_path.rfind(L'\\');
    if (sep != std::wstring::npos)
        driver_path = driver_path.substr(0, sep + 1);
    driver_path += L"spoofer.sys";

    std::cout << "[*] installing driver (auto-start)...\n";
    if (!install_driver_autostart(driver_path.c_str()))
        std::cout << "[!] driver install failed — kernel surfaces session-only this run\n";

    std::cout << "[*] spoofing registry surfaces...\n";
    spoof_registry();

    std::cout << "[*] spoofing wmi cache...\n";
    spoof_wmi();

    std::cout << "[*] spoofing nvidia...\n";
    spoof_nvidia();

    std::cout << "[*] spoofing tpm cache...\n";
    spoof_tpm();

    std::cout << "[*] cleaning fortnite / eac traces...\n";
    clean_fortnite();

    std::cout << "\n[+] all done — reboot to let driver patches settle.\n";
    std::cout << "[+] driver is set to AUTO-START — spoof is permanent across reboots.\n\n";
    system("pause");
    return 0;
}
