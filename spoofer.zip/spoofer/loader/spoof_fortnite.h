#pragma once
void clean_fortnite();
