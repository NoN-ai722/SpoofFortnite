#include "spoof_nvidia.h"
#include "config.h"
#include "gen.h"
#include <windows.h>
#include <string>
#include <iostream>

static std::wstring w(const std::string& s) { return std::wstring(s.begin(), s.end()); }

void spoof_nvidia() {
    const wchar_t* gpu_class =
        L"SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}";
    HKEY hClass;
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, gpu_class, 0,
        KEY_READ | KEY_WOW64_64KEY, &hClass) != ERROR_SUCCESS) return;

    wchar_t sub[256]; DWORD idx = 0, sl = 256;
    while (RegEnumKeyExW(hClass, idx++, sub, &sl, nullptr, nullptr, nullptr, nullptr) == ERROR_SUCCESS) {
        sl = 256;
        std::wstring subPath = std::wstring(gpu_class) + L"\\" + sub;
        HKEY hGpu;
        if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, subPath.c_str(), 0,
            KEY_READ | KEY_SET_VALUE | KEY_WOW64_64KEY, &hGpu) == ERROR_SUCCESS) {

            wchar_t desc[256] = {}; DWORD ds = sizeof(desc), t = REG_SZ;
            if (RegQueryValueExW(hGpu, L"DriverDesc", nullptr, &t,
                (BYTE*)desc, &ds) == ERROR_SUCCESS && wcsstr(desc, L"NVIDIA") != nullptr) {

                std::wstring nvserial = w(g_cfg.nvidia_serial);
                std::wstring nvmonid  = w(g_cfg.nvidia_monitor_id);
                std::wstring gpuguid  = w(g_cfg.machine_guid);

                RegSetValueExW(hGpu, L"Serial",    0, REG_SZ,
                    (const BYTE*)nvserial.c_str(), (DWORD)((nvserial.size() + 1) * 2));
                RegSetValueExW(hGpu, L"MonitorId", 0, REG_SZ,
                    (const BYTE*)nvmonid.c_str(),  (DWORD)((nvmonid.size() + 1) * 2));
                RegSetValueExW(hGpu, L"GpuGuid",   0, REG_SZ,
                    (const BYTE*)gpuguid.c_str(),  (DWORD)((gpuguid.size() + 1) * 2));

                // NVAPI GPU ID (hex string, 8 chars)
                std::wstring nvid = w(gen::random_hex(4));
                RegSetValueExW(hGpu, L"Device Description", 0, REG_SZ,
                    (const BYTE*)nvid.c_str(), (DWORD)((nvid.size() + 1) * 2));

                // Monitor serial under NVDMI subkey
                std::wstring monSubPath = subPath + L"\\NVDMI";
                HKEY hNvdmi;
                if (RegCreateKeyExW(HKEY_LOCAL_MACHINE, monSubPath.c_str(), 0, nullptr, 0,
                    KEY_SET_VALUE | KEY_WOW64_64KEY, nullptr, &hNvdmi, nullptr) == ERROR_SUCCESS) {
                    RegSetValueExW(hNvdmi, L"MonitorSerialNumber", 0, REG_SZ,
                        (const BYTE*)nvserial.c_str(), (DWORD)((nvserial.size() + 1) * 2));
                    RegCloseKey(hNvdmi);
                }
            }
            RegCloseKey(hGpu);
        }
    }
    RegCloseKey(hClass);
    std::cout << "[+] nvidia done\n";
}
