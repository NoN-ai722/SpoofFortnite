#include "spoof_fortnite.h"
#include <windows.h>
#include <shlobj.h>
#include <string>
#include <filesystem>
#include <iostream>
#pragma comment(lib, "shell32.lib")
namespace fs = std::filesystem;

static void wipe_dir(const fs::path& p) {
    if (!fs::exists(p)) return;
    std::error_code ec;
    for (auto& e : fs::recursive_directory_iterator(p, ec))
        if (fs::is_regular_file(e.path(), ec))
            fs::remove(e.path(), ec);
    std::cout << "  wiped " << p.string() << "\n";
}

static void wipe_file(const fs::path& p) {
    std::error_code ec;
    if (fs::exists(p, ec)) {
        fs::remove(p, ec);
        std::cout << "  removed " << p.string() << "\n";
    }
}

static fs::path get_path(int csidl) {
    wchar_t path[MAX_PATH] = {};
    SHGetFolderPathW(nullptr, csidl, nullptr, 0, path);
    return fs::path(path);
}

void clean_fortnite() {
    auto local   = get_path(CSIDL_LOCAL_APPDATA);
    auto roaming = get_path(CSIDL_APPDATA);
    auto pd      = get_path(CSIDL_COMMON_APPDATA);

    // EasyAntiCheat
    wipe_dir(pd    / "EasyAntiCheat");
    wipe_dir(local / "EasyAntiCheat");
    wipe_file(pd   / "EasyAntiCheat" / "ClientToken.dat");

    // BattlEye remnants
    wipe_dir(pd / "BattlEye");

    // Fortnite local cache
    wipe_dir(local / "FortniteGame");

    // Epic Games Launcher
    wipe_dir(local / "EpicGamesLauncher" / "Saved" / "Logs");
    wipe_dir(local / "EpicGamesLauncher" / "Saved" / "webcache");
    wipe_dir(local / "EpicGamesLauncher" / "Saved" / "Config");
    wipe_dir(local / "EpicGamesLauncher" / "Saved" / "Cookies");

    // Epic roaming device auth cache
    wipe_dir(roaming / "EpicGamesLauncher" / "Data" / "Saved");

    // UWP/MS Store package paths
    std::error_code ec;
    auto pkg_base = local / "Packages";
    if (fs::exists(pkg_base, ec)) {
        for (auto& e : fs::directory_iterator(pkg_base, ec)) {
            auto n = e.path().filename().string();
            if (n.find("Fortnite") != std::string::npos ||
                n.find("EpicGames") != std::string::npos) {
                wipe_dir(e.path() / "LocalState");
                wipe_dir(e.path() / "RoamingState");
                wipe_dir(e.path() / "AC" / "Temp");
            }
        }
    }

    // EAC device-id file locations (non-UWP)
    wipe_file(pd / "Epic Games" / "EpicGamesLauncher" / "Data" / "EMS" / "DeviceId.bin");
    wipe_file(local / "EpicGamesLauncher" / "Saved" / "Logs" / "EpicGamesLauncher.log");

    // Fortnite ban trace in AppData
    auto fn_config = local / "FortniteGame" / "Saved" / "Config" / "WindowsClient";
    wipe_dir(fn_config);

    std::cout << "[+] fortnite trace clean done\n";
}
