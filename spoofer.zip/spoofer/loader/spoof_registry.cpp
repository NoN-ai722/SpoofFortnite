#include "spoof_registry.h"
#include "config.h"
#include "gen.h"
#include <windows.h>
#include <string>
#include <iostream>
#include <sstream>

static std::wstring w(const std::string& s) { return std::wstring(s.begin(), s.end()); }

static bool write_sz(HKEY root, const wchar_t* path, const wchar_t* name, const std::wstring& val) {
    HKEY hk;
    if (RegCreateKeyExW(root, path, 0, nullptr, 0,
        KEY_SET_VALUE | KEY_WOW64_64KEY, nullptr, &hk, nullptr) != ERROR_SUCCESS)
        return false;
    bool ok = RegSetValueExW(hk, name, 0, REG_SZ,
        (const BYTE*)val.c_str(), (DWORD)((val.size() + 1) * 2)) == ERROR_SUCCESS;
    RegCloseKey(hk);
    return ok;
}

static bool write_bin(HKEY root, const wchar_t* path, const wchar_t* name,
    const void* data, DWORD sz) {
    HKEY hk;
    if (RegCreateKeyExW(root, path, 0, nullptr, 0,
        KEY_SET_VALUE | KEY_WOW64_64KEY, nullptr, &hk, nullptr) != ERROR_SUCCESS)
        return false;
    bool ok = RegSetValueExW(hk, name, 0, REG_BINARY,
        (const BYTE*)data, sz) == ERROR_SUCCESS;
    RegCloseKey(hk);
    return ok;
}

static void spoof_nic_subkeys(HKEY root, const wchar_t* base_path) {
    HKEY hBase;
    if (RegOpenKeyExW(root, base_path, 0, KEY_READ | KEY_WRITE | KEY_WOW64_64KEY, &hBase) != ERROR_SUCCESS)
        return;
    wchar_t subkey[256];
    DWORD idx = 0, len = 256;
    while (RegEnumKeyExW(hBase, idx++, subkey, &len, nullptr, nullptr, nullptr, nullptr) == ERROR_SUCCESS) {
        len = 256;
        HKEY hSub;
        std::wstring subPath = std::wstring(base_path) + L"\\" + subkey;
        if (RegOpenKeyExW(root, subPath.c_str(), 0,
            KEY_READ | KEY_SET_VALUE | KEY_WOW64_64KEY, &hSub) == ERROR_SUCCESS) {

            // Check ProviderName or NetCfgInstanceId exists before patching
            wchar_t desc[256] = {}; DWORD ds = sizeof(desc), t = REG_SZ;
            bool is_adapter = (RegQueryValueExW(hSub, L"NetCfgInstanceId",
                nullptr, &t, (BYTE*)desc, &ds) == ERROR_SUCCESS);

            if (is_adapter) {
                // NetCfgInstanceId
                std::wstring newguid = w(gen::random_guid());
                RegSetValueExW(hSub, L"NetCfgInstanceId", 0, REG_SZ,
                    (const BYTE*)newguid.c_str(), (DWORD)((newguid.size() + 1) * 2));

                // NetworkAddress (MAC override — NDIS reads this on bind)
                // Format: XXXXXXXXXXXX no colons
                std::string mac_raw = g_cfg.mac;
                std::string mac_noconn;
                for (char c : mac_raw) if (c != ':') mac_noconn += (char)toupper(c);
                std::wstring mac_w(mac_noconn.begin(), mac_noconn.end());
                RegSetValueExW(hSub, L"NetworkAddress", 0, REG_SZ,
                    (const BYTE*)mac_w.c_str(), (DWORD)((mac_w.size() + 1) * 2));
            }
            RegCloseKey(hSub);
        }
    }
    RegCloseKey(hBase);
}

static void spoof_usb_serials() {
    HKEY hUsb;
    const wchar_t* usb_path = L"SYSTEM\\CurrentControlSet\\Enum\\USB";
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, usb_path, 0,
        KEY_READ | KEY_WOW64_64KEY, &hUsb) != ERROR_SUCCESS) return;

    wchar_t devClass[256]; DWORD ci = 0, cl = 256;
    while (RegEnumKeyExW(hUsb, ci++, devClass, &cl, nullptr, nullptr, nullptr, nullptr) == ERROR_SUCCESS) {
        cl = 256;
        HKEY hClass;
        std::wstring classPath = std::wstring(usb_path) + L"\\" + devClass;
        if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, classPath.c_str(), 0,
            KEY_READ | KEY_WOW64_64KEY, &hClass) != ERROR_SUCCESS) continue;
        wchar_t inst[256]; DWORD ii = 0, il = 256;
        while (RegEnumKeyExW(hClass, ii++, inst, &il, nullptr, nullptr, nullptr, nullptr) == ERROR_SUCCESS) {
            il = 256;
            std::wstring instPath = classPath + L"\\" + inst;
            HKEY hInst;
            if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, instPath.c_str(), 0,
                KEY_SET_VALUE | KEY_WOW64_64KEY, &hInst) == ERROR_SUCCESS) {
                std::wstring newSerial = w(gen::random_serial(12));
                RegSetValueExW(hInst, L"SerialNumber", 0, REG_SZ,
                    (const BYTE*)newSerial.c_str(), (DWORD)((newSerial.size() + 1) * 2));
                RegCloseKey(hInst);
            }
        }
        RegCloseKey(hClass);
    }
    RegCloseKey(hUsb);
}

static void spoof_edid() {
    HKEY hDisp;
    const wchar_t* dp = L"SYSTEM\\CurrentControlSet\\Enum\\DISPLAY";
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, dp, 0,
        KEY_READ | KEY_WOW64_64KEY, &hDisp) != ERROR_SUCCESS) return;

    wchar_t mon[256]; DWORD mi = 0, ml = 256;
    while (RegEnumKeyExW(hDisp, mi++, mon, &ml, nullptr, nullptr, nullptr, nullptr) == ERROR_SUCCESS) {
        ml = 256;
        std::wstring monPath = std::wstring(dp) + L"\\" + mon;
        HKEY hMon;
        if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, monPath.c_str(), 0,
            KEY_READ | KEY_WOW64_64KEY, &hMon) == ERROR_SUCCESS) {
            wchar_t inst2[256]; DWORD ii = 0, il = 256;
            while (RegEnumKeyExW(hMon, ii++, inst2, &il, nullptr, nullptr, nullptr, nullptr) == ERROR_SUCCESS) {
                il = 256;
                std::wstring edidPath = monPath + L"\\" + inst2 + L"\\Device Parameters";
                HKEY hEdid;
                if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, edidPath.c_str(), 0,
                    KEY_READ | KEY_SET_VALUE | KEY_WOW64_64KEY, &hEdid) == ERROR_SUCCESS) {
                    BYTE edid[256] = {};
                    DWORD edidSz = sizeof(edid), t2 = REG_BINARY;
                    if (RegQueryValueExW(hEdid, L"EDID", nullptr, &t2, edid, &edidSz) == ERROR_SUCCESS
                        && edidSz >= 128) {
                        // Product code at bytes 8-9
                        edid[8] = (uint8_t)strtoul(g_cfg.edid_product_code.c_str(), nullptr, 16);
                        edid[9] = 0x00;
                        // Find serial descriptor (tag 0xFF) and overwrite
                        for (int d = 0; d < 4; ++d) {
                            int off = 54 + d * 18;
                            if (off + 18 <= (int)edidSz &&
                                edid[off] == 0 && edid[off + 1] == 0 &&
                                edid[off + 2] == 0 && edid[off + 3] == 0xFF) {
                                memset(&edid[off + 5], 0x20, 13);
                                size_t copy_len = min((size_t)13, g_cfg.edid_serial.size());
                                memcpy(&edid[off + 5], g_cfg.edid_serial.c_str(), copy_len);
                                break;
                            }
                        }
                        // Recompute checksum
                        uint8_t sum = 0;
                        for (int i = 0; i < 127; ++i) sum += edid[i];
                        edid[127] = (uint8_t)(256 - sum);
                        RegSetValueExW(hEdid, L"EDID", 0, REG_BINARY, edid, edidSz);
                    }
                    RegCloseKey(hEdid);
                }
            }
            RegCloseKey(hMon);
        }
    }
    RegCloseKey(hDisp);
}

void spoof_registry() {
    auto mac_w  = w(g_cfg.mac);
    auto disk_w = w(g_cfg.disk_serial);
    auto guid_w = w(g_cfg.machine_guid);
    auto name_w = w(g_cfg.computer_name);

    // MachineGuid
    write_sz(HKEY_LOCAL_MACHINE,
        L"SOFTWARE\\Microsoft\\Cryptography", L"MachineGuid", guid_w);

    // ComputerName
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Control\\ComputerName\\ComputerName",
        L"ComputerName", name_w);
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Control\\ComputerName\\ActiveComputerName",
        L"ComputerName", name_w);
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters",
        L"Hostname", name_w);
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters",
        L"NV Hostname", name_w);

    // HwProfileGuid
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Control\\IDConfigDB\\Hardware Profiles\\0001",
        L"HwProfileGuid", w(g_cfg.hw_profile_guid));

    // ProductId / EditionID
    write_sz(HKEY_LOCAL_MACHINE,
        L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion",
        L"ProductId", w(g_cfg.product_id));
    write_sz(HKEY_LOCAL_MACHINE,
        L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion",
        L"EditionID", L"Professional");

    // SusClientId
    write_sz(HKEY_LOCAL_MACHINE,
        L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\WindowsUpdate",
        L"SusClientId", w(g_cfg.sus_client_id));

    // SQM MachineId
    write_sz(HKEY_LOCAL_MACHINE,
        L"SOFTWARE\\Microsoft\\SQMClient",
        L"MachineId", w(g_cfg.sqm_machine_id));

    // DPId4
    write_sz(HKEY_LOCAL_MACHINE,
        L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion",
        L"DigitalProductId4", w(gen::random_serial(24)));

    // BootGuid
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Control",
        L"BootGuid", w(g_cfg.boot_guid));

    // BootOrder (binary — 2 bytes)
    uint8_t bootorder[] = { 0x00, 0x00 };
    write_bin(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Control",
        L"BootOrder", bootorder, sizeof(bootorder));

    // OfflineUniqueID / UnlockIDCopy / PlatformModuleData
    const wchar_t* oui_path =
        L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\CloudExperienceHost\\OfflineUniqueID";
    auto seed     = gen::random_bytes_32();
    auto seedcrc  = gen::random_bytes_32();
    auto ekpub    = gen::random_bytes_32();
    auto ekpubcrc = gen::random_bytes_32();
    auto pmd      = gen::random_bytes_32();
    write_bin(HKEY_LOCAL_MACHINE, oui_path, L"OfflineUniqueIDRandomSeed",    seed.data(),     32);
    write_bin(HKEY_LOCAL_MACHINE, oui_path, L"OfflineUniqueIDRandomSeedCRC", seedcrc.data(),  32);
    write_bin(HKEY_LOCAL_MACHINE, oui_path, L"OfflineUniqueIDEKPub",         ekpub.data(),    32);
    write_bin(HKEY_LOCAL_MACHINE, oui_path, L"OfflineUniqueIDEKPubCRC",      ekpubcrc.data(), 32);
    write_bin(HKEY_LOCAL_MACHINE, oui_path, L"UnlockIDCopy",                 seed.data(),     32);
    write_bin(HKEY_LOCAL_MACHINE, oui_path, L"PlatformModuleData",           pmd.data(),      32);

    // EDID
    spoof_edid();

    // NIC class — NDIS NetworkAddress + NetCfgInstanceId
    spoof_nic_subkeys(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e972-e325-11ce-bfc1-08002be10318}");

    // NetBT
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Services\\NetBT\\Parameters",
        L"TransportBindName", guid_w);

    // DHCPv4 client identifier
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters",
        L"DhcpClientIdentifier", mac_w);

    // DHCPv6 DUID and IAID
    {
        auto duid = gen::random_bytes_32();
        write_bin(HKEY_LOCAL_MACHINE,
            L"SYSTEM\\CurrentControlSet\\Services\\Tcpip6\\Parameters",
            L"Dhcpv6DUID", duid.data(), 14);
        uint32_t iaid = (uint32_t)strtoul(gen::random_hex(4).c_str(), nullptr, 16);
        write_bin(HKEY_LOCAL_MACHINE,
            L"SYSTEM\\CurrentControlSet\\Services\\Tcpip6\\Parameters",
            L"Dhcpv6IAID", &iaid, 4);
    }

    // UuidNode (cached MAC for UUID node field)
    {
        uint8_t mac_bin[6] = {};
        int vals[6] = {};
        sscanf_s(g_cfg.mac.c_str(), "%x:%x:%x:%x:%x:%x",
            &vals[0], &vals[1], &vals[2], &vals[3], &vals[4], &vals[5]);
        for (int i = 0; i < 6; ++i) mac_bin[i] = (uint8_t)vals[i];
        write_bin(HKEY_LOCAL_MACHINE,
            L"SOFTWARE\\Microsoft\\Rpc",
            L"UuidSequenceNumber", mac_bin, 6);
    }

    // Bluetooth
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Services\\BTHPORT\\Parameters\\LocalRadios",
        L"BDAddress", mac_w);

    // USB serials
    spoof_usb_serials();

    // SCSI Port 0
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Enum\\SCSI",
        L"SerialNumber", disk_w);

    // NSI network store
    write_sz(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Services\\nsi",
        L"DisplayName", w(gen::random_serial(8)));

    std::cout << "[+] registry done\n";
}
