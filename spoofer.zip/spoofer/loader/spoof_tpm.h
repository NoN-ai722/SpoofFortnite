#pragma once
void spoof_tpm();
