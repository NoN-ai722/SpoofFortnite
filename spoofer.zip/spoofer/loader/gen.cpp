#include "gen.h"
#include <windows.h>
#include <bcrypt.h>
#include <sstream>
#include <iomanip>
#include <vector>
#pragma comment(lib, "bcrypt.lib")

static std::vector<uint8_t> csprng(size_t n) {
    std::vector<uint8_t> buf(n);
    BCryptGenRandom(nullptr, buf.data(), (ULONG)n, BCRYPT_USE_SYSTEM_PREFERRED_RNG);
    return buf;
}

std::string gen::random_hex(size_t bytes) {
    auto b = csprng(bytes);
    std::ostringstream ss;
    for (auto x : b) ss << std::hex << std::setw(2) << std::setfill('0') << (int)x;
    return ss.str();
}

std::string gen::random_mac() {
    auto b = csprng(6);
    b[0] = (b[0] & 0xFC) | 0x02;
    std::ostringstream ss;
    for (int i = 0; i < 6; ++i) {
        if (i) ss << ':';
        ss << std::hex << std::setw(2) << std::setfill('0') << (int)b[i];
    }
    return ss.str();
}

std::string gen::random_guid() {
    auto b = csprng(16);
    b[6] = (b[6] & 0x0F) | 0x40;
    b[8] = (b[8] & 0x3F) | 0x80;
    std::ostringstream ss;
    ss << '{';
    for (int i = 0; i < 16; ++i) {
        if (i == 4 || i == 6 || i == 8 || i == 10) ss << '-';
        ss << std::hex << std::setw(2) << std::setfill('0') << (int)b[i];
    }
    ss << '}';
    std::string s = ss.str();
    for (auto& c : s) c = (char)toupper(c);
    return s;
}

std::string gen::random_serial(size_t len) {
    const char charset[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    auto b = csprng(len);
    std::string s(len, ' ');
    for (size_t i = 0; i < len; ++i)
        s[i] = charset[b[i] % (sizeof(charset) - 1)];
    return s;
}

std::string gen::random_uuid_str() { return random_guid(); }

std::array<uint8_t, 32> gen::random_bytes_32() {
    auto b = csprng(32);
    std::array<uint8_t, 32> arr{};
    std::copy(b.begin(), b.end(), arr.begin());
    return arr;
}
