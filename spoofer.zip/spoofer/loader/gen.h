#pragma once
#include <string>
#include <array>
#include <cstdint>

namespace gen {
    std::string random_hex(size_t bytes);
    std::string random_mac();
    std::string random_guid();
    std::string random_serial(size_t len = 16);
    std::string random_uuid_str();
    std::array<uint8_t, 32> random_bytes_32();
}
